
// Initialize Energy Calculator Widget
document.addEventListener('DOMContentLoaded', function() {
  const widgets = document.querySelectorAll('.energy-calculator-widget');
  widgets.forEach(function(widget) {
    window.ReactDOM.createRoot(widget).render(
      window.React.createElement(window.EnergyCalculator.default)
    );
  });
});
