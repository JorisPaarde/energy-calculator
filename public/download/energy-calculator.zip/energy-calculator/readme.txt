=== Energy Calculator ===
Contributors: jpwebcreation
Tags: energy label, calculator, utilities, energy efficiency, building energy
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.10
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Generate energy label indications for buildings based on user input. Created by JPwebcreation (www.jpwebcreation.nl).

== Description ==
The Energy Calculator plugin helps users generate an energy label indication for their building based on various input parameters. This tool provides a quick and easy way to get an indication of a building's energy efficiency rating.

Created by JPwebcreation (www.jpwebcreation.nl), this calculator offers:
* Simple and intuitive interface
* Instant energy label indication
* Visual representation of the energy label
* Easy to integrate using shortcode

== Installation ==
1. Upload the plugin files to the /wp-content/plugins/energy-calculator directory
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the shortcode [energy_calculator] to display the calculator on any page or post

== Frequently Asked Questions ==
= Is this an official energy label? =
No, this calculator provides an indication only. For an official energy label, please consult an authorized energy advisor.

= How do I contact the developer? =
You can reach out to JPwebcreation at www.jpwebcreation.nl

== Changelog ==
= 1.0.10 =
* Initial release of the Energy Label Calculator

== Credits ==
Developed by JPwebcreation (www.jpwebcreation.nl)
